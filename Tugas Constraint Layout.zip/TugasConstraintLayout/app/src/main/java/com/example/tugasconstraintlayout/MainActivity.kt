package com.example.tugasconstraintlayout

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var fullnameEditText: EditText
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var signUpButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inisialisasi EditText dan Button
        emailEditText = findViewById(R.id.emailEditText)
        fullnameEditText = findViewById(R.id.fullnameEditText)
        usernameEditText = findViewById(R.id.usernameEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        signUpButton = findViewById(R.id.signUpButton)

        // Set OnClickListener untuk tombol Sign Up
        signUpButton.setOnClickListener {
            // Ambil nilai dari EditText
            val email = emailEditText.text.toString()
            val fullname = fullnameEditText.text.toString()
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Tampilkan Toast dengan data inputan pengguna
            Toast.makeText(this,
                "Email: $email\nFullname: $fullname\nUsername: $username\nPassword: $password",
                Toast.LENGTH_LONG).show()
        }
    }
}
